exports.handler = async (event) => {
    const response = {
        result: "original"
    };
    return response;
};

